function SWiFiUI
%initialize UI and data structure
handles.h=figure('units','normalized','outerposition',[0 0 .8 .8],'Visible','off','NumberTitle','off');
handles.g=figure('units','normalized','outerposition',[0 0 .8 .8],'Visible','off','NumberTitle','off','Name','TrakCen Results');
handles.f=figure('Visible','off');
handles.c=figure('Visible','off');
handles.b=figure('Visible','off');
handles.a=figure('Visible','off');
[fileName,PathName]=uigetfile('*.tif');
set(handles.h,'Name',strcat('SWiFi: ',fileName));
set(handles.g,'Name',strcat('SWiFi results: ',fileName));
%finds how many files belong to the current acquisition
filelist=dir(fullfile(PathName,strcat(fileName(1:end-4),'*.tif'))); 
%%this format should be change to the file system of your microscope
numFile=length(filelist);
handles.map=importdata(uigetfile('map*.mat'));
%map.mat is a file which contains the definitions of the two channels along
%with a 2D polynomial transformation between them
list.info=imfinfo(fullfile(PathName,fileName));
handles.Height=list.info.Height;
handles.fileName=fileName;
handles.PathName=PathName;
handles.tracks=[];
handles.flag=0;
%find how many frames exist in each file of the acquisition 
%to be used by the tracking software
for i=2:numFile
    list(i).info=imfinfo(fullfile(PathName,strcat(fileName(1:end-8),'_',num2str(i-1,'%d'),'.ome.tif')));%for NIM2
    %%change this according to your own acquistion file system
end
%finds total number of frames
totFrames=0;
for i=1:numFile
    totFrames=totFrames+length(list(i).info);
    Frames(i)=length(list(i).info);
end
handles.frames=Frames;
handles.totFrames=totFrames;
%make the GUI the current figure
set(0,'CurrentFigure',handles.h);
%read the first frame
I=imread(fullfile(PathName,fileName),1);
acq=I;
warning('off','all')
Imsize=size(I);
%% initialize UI controls for the current figure
handles.axes1=axes('Parent',handles.h,'Units','pixels','Position',[10 150 Imsize(2)*2/3 Imsize(1)*2/3]);
imshow(I,[mean(I(:))-std(double(I(:))) mean(I(:))+3*std(double(I(:)))]);
% show the first frame
Pos=handles.axes1.Position;
handles.slider1=uicontrol('Parent',handles.h,'Style','slider','Min',1,'Max',totFrames,'Value',1,'Tag','slider1','Units','pixels','Position',[Pos(1)+Imsize(2)/12 Pos(2)-20 Imsize(2)/2 20],'callback',@slider1_Callback);
handles.slider1.UserData.acq=acq;
handles.slider1.UserData.I=I;
Slpos=handles.slider1.Position;
handles.minInt=uicontrol('Parent',handles.h,'Style','edit','String','minimum intensity','Tag','minInt','UserData',400,'Units','pixels','position',[Slpos(1)+Slpos(3)/2-140 Slpos(2)-30 120 25],'FontSize',8,'callback',@minInt_Callback);
handles.maxInt=uicontrol('Parent',handles.h,'Style','edit','String','maximum intensity','Tag','maxInt','UserData',700,'Units','pixels','position',[Slpos(1)+Slpos(3)/2+10 Slpos(2)-30 120 25],'FontSize',8,'callback',@maxInt_Callback);
handles.frameNumber = uicontrol('Parent',handles.h,'Style','text','String','1','Tag','frameNumber','Units','pixels','position',[Pos(1)+Pos(3)-60 Pos(2)+Pos(4)+5 60 20],'FontSize',10,'BackgroundColor','white');
handles.localize=uicontrol('Parent',handles.h,'Style','pushbutton','String','localize!','Tag','localize','Units','pixels','position',[Pos(1)+100+Pos(3) Pos(2)+100 70 30],'FontSize',10,'callback',@localize_Callback);
anPos=handles.localize.Position +[0 70 0 0];
handles.analyze=uicontrol('Parent',handles.h,'Style','pushbutton','String','track!','Tag','track','Units','pixels','position',anPos+[0 -140 0 0],'FontSize',10,'callback',@analyze_callback);
trPos=anPos+[-30 60 60 0];
handles.trackMode=uicontrol('Parent',handles.h,'Style','popup','String',{'regular track','FRET track'},'Tag','trackMode','Units','pixels','position',trPos,'FontSize',10,'callback',@trackMode_Callback);
FRETPos=handles.trackMode.Position+[0 60 0 0];
handles.FRETmode=uicontrol('Parent',handles.h,'Style','popup','String',{'continuous','Alex'},'Tag','FRETmode','Units','pixels','position',FRETPos,'FontSize',10,'Visible','off');
ChPos=handles.FRETmode.Position+[-25 60 50 0];
handles.Channel=uicontrol('Parent',handles.h,'Style','edit','String','channel: green, red or merged','Tag','Channel','Units','pixels','position',ChPos,'FontSize',8,'callback',@Channel_Callback);
mDPos=handles.Channel.Position+[0 60 0 0];
handles.maxDist=uicontrol('Parent',handles.h,'Style','edit','String','maximum allowed distance [10]','Tag','maxDist','Units','pixels','Value',10,'position',mDPos,'FontSize',8,'callback',@maxDist_Callback);
handles.minTrack=uicontrol('Parent',handles.h,'Style','edit','String','minimum track length [3]','Tag','minTrack','Units','pixels','Value',3,'position',mDPos+[0 60 0 0],'FontSize',8,'callback',@minTrack_Callback); 
handles.exposure=uicontrol('Parent',handles.h,'Style','edit','String','exposure time [s]','Tag','exposure','Units','pixels','position',mDPos+[250 0 0 0],'FontSize',8,'callback',@exposure_Callback);
handles.maxFrames=uicontrol('Parent',handles.h,'Style','edit','String','maximum frames to skip','Tag','maxFrames','Units','pixels','position',ChPos+[250 0 0 0],'FontSize',8,'callback',@maxFrames_Callback);
handles.Maxsize=uicontrol('Parent',handles.h,'Style','edit','String','maximum size [150]','Tag','Maxsize','Units','pixels','Value',150,'position',ChPos+[210 -60 -60 0],'FontSize',8,'callback',@Maxsize_Callback);
handles.viscosity=uicontrol('Parent',handles.h,'Style','edit','String','viscosity [Ns/m^2]','Tag','viscosity','Units','pixels','position',ChPos+[210 -120 -60 0],'FontSize',8);
handles.minsize=uicontrol('Parent',handles.h,'Style','edit','String','minimum size [3]','Tag','minsize','Units','pixels','Value',3,'position',ChPos+[350 -60 -60 0],'FontSize',8,'callback',@minsize_Callback);
handles.temperature=uicontrol('Parent',handles.h,'Style','edit','String','temperature[C]','Tag','temperature','Units','pixels','position',ChPos+[350 -120 -60 0],'FontSize',8);
handles.Sensitivity=uitable('Parent',handles.h,'Tag','Sensitivity','Units','pixels','Data',{0.55,0.55,0.55,51},'ColumnName',{'DD','DA','AA','N'},'ColumnEdit',[true true true true],'position',handles.maxFrames.Position+[-40 -230 180 20],'FontSize',8);
uicontrol('parent',handles.h,'Style','text','String','Sensitivity','position',handles.Sensitivity.Position+[30 50 -40 -30]);
set(handles.slider1, 'SliderStep', [1/(totFrames-1) , 10/(totFrames-1)]);
%% build results panel uI
handles2.axes2=axes('Parent',handles.g,'Units','pixels','Position',[10 150 Imsize(2)*2/3 Imsize(1)*2/3]);
handles2.slider=uicontrol('Parent',handles.g,'Style','slider','Min',1,'Max',totFrames,'Value',1,'Tag','slider2','Units','pixels','Position',[Pos(1)+Imsize(2)/12 Pos(2)-20 Imsize(2)/2 20],'callback',@slider2_Callback);
set(handles2.slider, 'SliderStep', [1/(totFrames-1) , 10/(totFrames-1)]);
handles2.frameNum=uicontrol('Parent',handles.g,'Style','text','String','1','Tag','frameNum2','Units','pixels','position',[Pos(1)+5+Pos(3) Pos(2)+Pos(4)-100 60 20],'FontSize',10,'BackgroundColor','white');
handles2.minInt=uicontrol('Parent',handles.g,'Style','edit','String','minimum intensity','Tag','minInt2','Units','pixels','position',[Slpos(1)+Slpos(3)/2-140 Slpos(2)-30 120 25],'FontSize',8,'callback',@minInt2_Callback);
handles2.maxInt=uicontrol('Parent',handles.g,'Style','edit','String','maximum intensity','Tag','maxInt2','Units','pixels','position',[Slpos(1)+Slpos(3)/2+10 Slpos(2)-30 120 25],'FontSize',8,'callback',@maxInt2_Callback);
handles2.listBox=uicontrol('Parent',handles.g,'Style','listbox','Visible','off','Tag','listBox','String',[],'Max',10,'Units','pixels','Position',handles.analyze.Position+[400 200 0 225],'callback',@listBox_Callback);
handles2.listBoxinitpos=handles2.listBox.Position;
handles2.Dvalues=uicontrol('Parent',handles.g,'Style','text','Visible','off','Tag','Dvalues','String',[],'Units','pixels','Position',handles2.listBox.Position+[-200 100 0 0]);
handles2.closeg=uicontrol('Parent',handles.g,'Style','pushbutton','String','close','Tag','close','Units','pixels','position',anPos+[0 -140 0 0],'FontSize',10,'callback',@closeg_callback);
%% Update handles structure
guidata(handles.h,handles)
guidata(handles.g,handles2)
handles.h.Visible = 'on';

%% UI callbacks 
% --- Executes on slider movement.
    function slider1_Callback(hObject,~)
        % this callback controls the slider for the initiation figure.
        % hObject    handle to slider1 (see GCBO)        
        % handles    structure with handles and user data (see GUIDATA)
        
        
        %loads the current image based on slider value
        framesTot=cumsum(handles.frames);
        frameNum=round(get(hObject,'Value'));   
        j=1;
        if frameNum<=framesTot(1)
            I=imread(fullfile(handles.PathName,handles.fileName),frameNum);
        else
            while frameNum>framesTot(j)    
                FileName=fullfile(handles.PathName,strcat(fileName(1:end-8),'_',num2str(j,'%d'),'.ome.tif'));
                j=j+1;
            end
             I=imread(FileName,frameNum-framesTot(j-1));
        end   
        %display current frame number
        handles.frameNumber.String=sprintf('%u',frameNum);
        %display the current channel ('green', 'red' or merged)
        if strcmp(handles.Channel.String,'green')
            if handles.Height==1024
                acq=I(handles.map.coords{1}(2):handles.map.coords{1}(2)+handles.map.coords{1}(4)-1,handles.map.coords{1}(1):handles.map.coords{1}(1)+handles.map.coords{1}(3)-1);
            else
                acq=I(:,handles.map.coords{1}(1):handles.map.coords{1}(1)+handles.map.coords{1}(3)-1);
            end
        elseif strcmp(handles.Channel.String,'red')
            if handles.Height==1024
                acq=I(handles.map.coords{2}(2):handles.map.coords{2}(2)+handles.map.coords{2}(4)-1,handles.map.coords{2}(1):handles.map.coords{2}(1)+handles.map.coords{2}(3)-1);
            else
                acq=I(:,handles.map.coords{2}(1):handles.map.coords{2}(1)+handles.map.coords{2}(3)-1);
            end
        else
            acq=I;
        end
        hObject.UserData.acq=acq;
        hObject.UserData.I=I;
        imshow(medfilt2(hObject.UserData.acq,[3 3]),[handles.minInt.UserData handles.maxInt.UserData])
    end

%% --- Executes on slider movement.
    function slider2_Callback(hObject,~)
        % this callback controls the slider for the results GUI.
        % hObject    handle to slider1 (see GCBO)
        % handles    structure with handles and user data (see GUIDATA)
        

        frameNum=round(get(hObject,'Value'));        
        handles2.frameNum.String=sprintf('%u',frameNum);
        I=imread(fullfile(handles.PathName,handles.fileName),frameNum);
        if strcmp(handles.Channel.String,'green')
            if handles.Height==1024
                acq=I(handles.map.coords{1}(2):handles.map.coords{1}(2)+handles.map.coords{1}(4)-1,handles.map.coords{1}(1):handles.map.coords{1}(1)+handles.map.coords{1}(3)-1);
            else
                acq=I(:,handles.map.coords{1}(1):handles.map.coords{1}(1)+handles.map.coords{1}(3)-1);
            end
        elseif strcmp(handles.Channel.String,'red')
            if handles.Height==1024
                acq=I(handles.map.coords{2}(2):handles.map.coords{2}(2)+handles.map.coords{2}(4)-1,handles.map.coords{2}(1):handles.map.coords{2}(1)+handles.map.coords{2}(3)-1);
            else
                acq=I(:,handles.map.coords{2}(1):handles.map.coords{2}(1)+handles.map.coords{2}(3)-1);
            end
        else
            acq=I;
        end
        hObject.UserData.acq=medfilt2(acq,[3 3]);
        hObject.UserData.I=I;   
        imshow(hObject.UserData.acq,[handles2.minInt.UserData handles2.maxInt.UserData]);
        hold on
        %plot all tracks that are active in frame=framNum
        currTrack=handles.tracks(1).coords(frameNum,:)>0; %tracks in current frame
        coord=handles.tracks(1).coords(:,currTrack);
        X=coord(:,1:2:end);
        ind=find(currTrack);
        ind=ind(1:2:end); %if there is more than one  
        Y=coord(:,2:2:end);
        A=zeros(length(X(1,:)),3);
        if ~isempty(X)
            for j=1:length(X(1,:))
                A(j,1)=ind(j);
                A(j,2)=handles.particle(ceil(ind(j)/2)).D*1e12;
                A(j,3)=handles.particle(ceil(ind(j)/2)).R*1e9;
                plot(X(X(:,j)>0,j),Y(X(:,j)>0,j),'LineWidth',2);
                startX=X(X(:,j)>0,j);
                startY=Y(X(:,j)>0,j);
                text(round(startX(1)),round(startY(1)),sprintf('%d',ind(j)),'FontSize',8,'Color',[.3 1 .8]);
            end
            set(handles2.listBox,'String',num2str(A(:,1)),'Value',length(X(1,:)));
        end  
        hold off
    end
%% --excutes when a box list track is chosen, displays relevant parameters as well as FRET trace    
    function listBox_Callback(hObject,~)
        %finds which items have been chosen and displays the corresponding
        %properties
       items = cellstr(get(hObject,'String'));
       index_selected = get(hObject,'Value');
       item_selected = items(index_selected);
       S=sprintf('%s ', item_selected{:});
       ind=sscanf(S,'%d');
       A=zeros(length(ind),3);
       A(:,1)=ind;
       D=[handles.particle.D];
       A(:,2)=D(ceil(ind/2))*1e12;
       R=[handles.particle.R];
       A(:,3)=R(ceil(ind/2))*1e9;
       Table=array2table(A,'VariableNames',{'track','D','R'});
       if ~isfield(handles2,'T')
           handles2.T=uitable('Parent',handles.g,'Data',Table{:,:},'ColumnName',Table.Properties.VariableNames,'Units','pixels','Position',[handles2.listBox.Position(1) handles2.listBox.Position(2)+50+25*length(ind) 300 25*length(ind)]);
       else
           handles2.T.Data=Table{:,:};
           set(handles2.T,'Position',[handles2.listBox.Position(1)-200 handles2.listBox.Position(2)-50-25*length(ind) 260 20+25*length(ind)]);
       end 
       %displays the relevant FRET trace if one exists
       if isfield (handles.tracks(1),'eFRET')
           set(0,'CurrentFigure',handles.b)
           for j=1:length(ind)
               subplot(length(ind),1,j)
               plot(handles.tracks(1).eFRET(handles.tracks(1).eFRET(:,ind(j))>0,ind(j)));
               xlabel('time [frames]');
               ylabel('E*');
           end
           handles.b.Visible='on';
           set(handles.b,'Name','FRET trace');
       end
       set(0,'CurrentFigure',handles.g);
    end
%%
    function exposure_Callback(hObject,~)
        handles.exposure.Value=str2double(get(hObject,'String'));
    end
%%
    function closeg_callback(hObject,~)
      handles.g.Visible='off';
    end  
%%
    function Channel_Callback(hObject,~)
        %defines the current channel and updates the dispaly
        % hObject    handle to Channel (see GCBO)
        if strcmp(hObject.String,'green')
            hObject.Value=1;
            if handles.Height==1024
                acq=handles.slider1.UserData.I(handles.map.coords{1}(2):handles.map.coords{1}(2)+handles.map.coords{1}(4)-1,handles.map.coords{1}(1):handles.map.coords{1}(1)+handles.map.coords{1}(3)-1);
            else
                acq=handles.slider1.UserData.I(:,handles.map.coords{1}(1):handles.map.coords{1}(1)+handles.map.coords{1}(3)-1);
            end
        elseif strcmp(hObject.String,'red')
            if strcmp(handles.FRETmode.String,'Alex')
                hObject.Value=3;
            else
                hObject.Value=2;
            end    
            if handles.Height==1024
                acq=handles.slider1.UserData.I(handles.map.coords{2}(2):handles.map.coords{2}(2)+handles.map.coords{2}(4)-1,handles.map.coords{2}(1):handles.map.coords{2}(1)+handles.map.coords{2}(3)-1);
            else
                acq=handles.slider1.UserData.I(:,handles.map.coords{2}(1):handles.map.coords{2}(1)+handles.map.coords{2}(3)-1);
            end
        else
            hObject.Value=0;
            acq=handles.slider1.UserData.I;
        end
        imshow(medfilt2(acq,[3 3]),[handles.minInt.UserData handles.maxInt.UserData]);
        handles.slider1.UserData.acq=acq;
    end
%%
    function minTrack_Callback(hObject,~)
        hObject.Value=str2double(get(hObject,'String'));
    end
%%
    function minsize_Callback(hObject,~)
        hObject.Value=str2double(get(hObject,'String'));
    end
%%
    function Maxsize_Callback(hObject,~)
        hObject.Value=str2double(get(hObject,'String'));
    end
%%
    function maxDist_Callback(hObject,~)
        hObject.Value=str2double(get(hObject,'String'));
    end
%%
    function maxFrames_Callback(hObject,~)
        hObject.Value=str2double(get(hObject,'String'));
    end
%%
    function trackMode_Callback(hObject,~)
        %defines the tracking mode: "regular" or "FRET" and makes the FRET
        %mode selection visible if necessary
        if hObject.Value==2
            handles.FRETmode.Visible='on';
            guidata(handles.h,handles)
        else
             handles.FRETmode.Visible='off';
            guidata(handles.h,handles)
        end    
    end    
%%
% --- Executes on button press in localize.
    function localize_Callback(hObject,~)
        %this function performs localization and displays the results
        %defines the sensitivity to be used for the segmentation depending
        %on the relevant channel
        switch handles.Channel.Value
            case 0
                S=0.55;
            case 1
                S=handles.Sensitivity.Data{1};
            case 2
                S=handles.Sensitivity.Data{2};
            case 3
                S=handles.Sensitivity.Data{3};
        end
        %localize 
        [spotcoord]=Localize(medfilt2(handles.slider1.UserData.acq,[3 3]),handles.minsize.Value,handles.Maxsize.Value,S,handles.Sensitivity.Data{4});
        X=spotcoord(1:2:end);
        Y=spotcoord(2:2:end);
        %display results on screen for evaluation
        imshow(medfilt2(handles.slider1.UserData.acq,[3 3]),[handles.minInt.UserData handles.maxInt.UserData])
        hold on
        scatter(X,Y,'+','red');
        hold off
    end
%% min and max intensity scaling for slider1

    function minInt_Callback(hObject,~)
        handles.minInt.UserData=str2double(get(hObject,'String'));
        if ~isempty(handles.maxInt.UserData)
            imshow(handles.slider1.UserData.acq,[handles.minInt.UserData,handles.maxInt.UserData]);
            handles.maxInt.String=sprintf('%u',handles.maxInt.UserData);
        else
            imshow(handles.slider1.UserData.acq,[handles.minInt.UserData,round(mean(handles.slider1.UserData.acq(:))+2*std(double(handles.slider1.UserData.acq(:))))]);
            Maxint=round(mean(handles.slider1.UserData.acq(:))+2*std(double(handles.slider1.UserData.acq(:))));
            handles.maxInt.String=sprintf('%u',Maxint);
            handles.maxInt.UserData=Maxint;
        end
         guidata(handles.h,handles)
    end



    function maxInt_Callback(hObject,~)
        handles.maxInt.UserData=str2double(get(hObject,'String'));
        if ~isempty(handles.minInt.UserData)
            imshow(handles.slider1.UserData.acq,[handles.minInt.UserData handles.maxInt.UserData]);
        else
            handles.minInt.UserData=mean(handles.slider1.UserData.acq(:))-round(std(double(handles.slider1.UserData.acq(:))));
            handles.minInt.String=sprintf('%d',handles.minInt.UserData);
            imshow(handles.slider1.UserData.acq,[handles.minInt.UserData handles.maxInt.UserData]);
        end
        guidata(handles.h,handles)
    end
%% min and max intensity scaling for slider2
    function minInt2_Callback(hObject,~)
        % hObject    handle to minInt (see GCBO)
        % eventdata  reserved - to be defined in a future version of MATLAB
        % handles    structure with handles and user data (see GUIDATA)
        
        % Hints: get(hObject,'String') returns contents of minInt as text
        %        str2double(get(hObject,'String')) returns contents of minInt as a double
        handles2.minInt.UserData=str2double(get(hObject,'String'));
        if ~isempty(handles2.maxInt.UserData)
            imshow(handles2.slider.UserData.acq,[handles2.minInt.UserData,handles2.maxInt.UserData]);
        else
            imshow(handles2.slider.UserData.acq,[handles2.minInt.UserData,round(mean(handles2.slider.UserData.acq(:))+2*std(double(handles2.slider.UserData.acq(:))))]);
            handles2.Maxint=round(mean(handles2.slider.UserData.acq(:))+2*std(double(handles2.slider.UserData.acq(:))));
            handles2.maxInt.String=sprintf('%u',handles2.Maxint);
        end
        guidata(handles.g,handles2)
    end

    function maxInt2_Callback(hObject,~)
        % hObject    handle to maxInt (see GCBO)
        % eventdata  reserved - to be defined in a future version of MATLAB
        % handles    structure with handles and user data (see GUIDATA)
        
        % Hints: get(hObject,'String') returns contents of maxInt as text
        %        str2double(get(hObject,'String')) returns contents of maxInt as a double
        handles2.maxInt.UserData=str2double(get(hObject,'String'));
        if ~isempty(handles2.minInt.UserData)
            imshow(handles2.slider.UserData.acq,[handles2.minInt.UserData handles2.maxInt.UserData]);
        else
            handles2.minInt.UserData=mean(handles2.slider.UserData.acq(:))-round(std(double(handles2.slider.UserData.acq(:))));
            handles2.minInt.String=sprintf('%d',handles2.minInt.UserData);
            imshow(handles2.slider.UserData.acq,[handles2.minInt.UserData handles2.maxInt.UserData]);
        end
        guidata(handles.g,handles2)
    end
%% This function calls the functions for tracking and analysis
    function analyze_callback(hObject,~)
        if handles.exposure.Value==0
            warndlg('Please define an exposure time')
            return
        end
        if strcmp(handles.viscosity,'viscosity')||strcmp(handles.temperature,'temperature')
            warndlg('Please enter the viscosity and/or temperature')
            return
        end
        %get the relevant parameters for tracking
        View=handles.Channel.String;
        if handles.maxDist.Value~=0
            maxDist=handles.maxDist.Value;
        else
            maxDist=10;
        end
        NeighbourDist=maxDist*1.5; %defines the minimal neighbour distance as 1.5 times the maximum allowed distance 
                                   %to reduce confusion
        if handles.maxFrames.Value~=0
            maxFrames=handles.maxFrames.Value;
        else
            maxFrames=3;
        end
        %get minimum track length
        if isnan(str2double(handles.minTrack.String))
            trackLength=3;
        else
            trackLength=str2double(handles.minTrack.String);
        end    
        %track!
        switch handles.trackMode.Value
            %This is the regular tracking based on the Hungarian assignment
            case 1
                [handles.tracks]=trackUI(handles.fileName,handles.PathName,maxDist,NeighbourDist,maxFrames,View,...
                 handles.minsize.Value,handles.Maxsize.Value,handles.Sensitivity.Data,handles.exposure.Value,handles.totFrames,handles.frames,handles.minTrack.Value);
                Ind=sum(handles.tracks.coords~=0,1)>=trackLength+1;
                handles.tracks.coords=handles.tracks.coords(:,Ind);
             %this is FRET tracking based on greedy near neighbor   
            case 2
                [handles.tracks]=trackFRETUI(handles.fileName,handles.PathName,maxDist,NeighbourDist,handles.minsize.Value,...
                 handles.Maxsize.Value,handles.Sensitivity.Data,handles.FRETmode.Value,handles.totFrames,handles.frames,'nim2',handles.map,trackLength);
             %remove tracks below track length
                Ind=sum(handles.tracks(1).coords~=0,1)>=trackLength;
                Ind=Ind(1:2:end);
                handles.tracks(1).photons=handles.tracks(1).photons(:,Ind);
                handles.tracks(2).photons=handles.tracks(2).photons(:,Ind);
                handles.tracks(1).eFRET=handles.tracks(1).eFRET(:,Ind); %for FRET
                Ind=sum(handles.tracks(1).coords~=0,1)>=trackLength; %for coordinates
                handles.tracks(1).coords=handles.tracks(1).coords(:,Ind);
        end
 %%     This section analyses the tracks to find diffusion,size and FRET distributions  
        viscosity=str2double(handles.viscosity.String);
        Temperature=str2double(handles.temperature.String);
        Size=size(handles.slider1.UserData.acq);
        [handles.particle,pxtot,pytot,D,handles.tracks]=trackAnalysisUI(handles.tracks,viscosity,Temperature,handles.exposure.Value,Size);
        handles.Dscale=[2:2:30 35:5:100];
        handles.Rscale=5*10^-1:5*10^-1:400;
        handles.f.Visible='on';
        set(0,'CurrentFigure',handles.f)
        ax=subplot(2,1,1);handles.Dhis=histogram(D*1E12,linspace(0,max(D*1e12),50));
        ax.XLabel.String='D [\mu^2/s]';
        bx=subplot(2,1,2);handles.dia=histogram(1E9*2*1.38E-23*(Temperature+273.15)/(6*pi*viscosity)*D.^(-1),linspace(0,100,50));
        bx.XLabel.String='Diameter [nm]';
        handles.c.Visible='on';
        set(0,'CurrentFigure',handles.c);
        plot(pxtot);
        xlabel('steps');
        ylabel('MSD [\mu^2/s]');
        hold on
        plot(pytot,'red')
        hold off
        legend('Px','Py','show')
        if handles.trackMode.Value==2
             set(0,'CurrentFigure',handles.a)
             handles.eFREThis=histogram(handles.tracks(1).eFRET(handles.tracks(1).eFRET>0&handles.tracks(1).eFRET<1&~isnan(handles.tracks(1).eFRET)));
             xlabel('E*');
             handles.a.Visible='on';
        end     
%% initiaites results GUI        
        handles2.minInt.UserData=handles.minInt.UserData;
        handles2.maxInt.UserData=handles.maxInt.UserData;
        handles2.minInt.String=handles.minInt.String;
        handles2.maxInt.String=handles.maxInt.String;
        handles2.slider.UserData.acq=handles.slider1.UserData.acq;
        set(0,'CurrentFigure',handles.g);
        imshow(handles2.slider.UserData.acq,[handles2.minInt.UserData handles2.maxInt.UserData]);
        if ~strcmp(handles.Channel.String,'merged')
            set(handles.g,'outerposition',[0 0 0.6 0.8]);
            set (handles2.listBox,'position',handles2.listBoxinitpos+[-200 0 0 0]);
        end    
        handles.g.Visible='on';
        handles2.listBox.Visible='on';
        Particle=handles.particle;
        Tracks=handles.tracks;
        save(fullfile(handles.PathName,strcat(handles.fileName(1:end-4),'.analysis.mat')),'Particle','Tracks','-v7.3');        
    end
end