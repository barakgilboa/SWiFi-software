function [tracks]= trackUI(fileName,PathName,maxDist,NeigbourDist,maxFrameStep,View,minSize,maxSize,S,exptime,totFrames,Frames,minTrack)
%%tracks particles based on the weighted centroid method. uses the tracking
%%algorithm of Konstanz university with the Gurobi solver and x^2+y^2+maxDist*t^2 as
%%the cost function to connect spots to tracks.
%%- maxDist- maximal distance between particles from the same track in
%%consecutive frames
%%-NieghbourDist - nearest neighbour criterion
%%-MaxFrameStep- maximal distance between frames that a particle reappearing
%%will be regarded as the same particle
%%-View- lists the channel to analyze- green,red,merged
%%-minSize- minimum spot size
%%-maxSize-maximum spot size
%%S- thresholding sensitivity. relevant values lies between 0.55 to 0.6.
%%Default is 0.55.

filelist=dir(fullfile(PathName,strcat(fileName(1:end-8),'*.tif'))); %Change this to your file naming system
numFile=length(filelist);
map=importdata(fullfile(PathName,'map.mat'));
list.info=imfinfo(fullfile(PathName,fileName));
framesPerFile=length(list.info);
Height=list.info.Height;  
formatspec='This is frame %d out of %d';
tracks(1).coords=zeros(totFrames*20,3);%initial estimate of 20 tracks per frame
I=imread(fullfile(PathName,fileName),1);
if strcmp(View,'merged')
    acq=medfilt2(I,[3 3]);
    [spotcoord]=Localize(acq,minSize,maxSize,(S{1}+S{2})/2,S{4});
elseif strcmp(View,'green')
    if Height==1024
        acq=I(map.coords{1}(2):map.coords{1}(2)+map.coords{1}(4)-1,map.coords{1}(1):map.coords{1}(1)+map.coords{1}(3)-1);
    else
        acq=I(:,map.coords{1}(1):map.coords{1}(1)+map.coords{1}(3)-1);
    end
    acq=medfilt2(acq,[3 3]);
    [spotcoord]=Localize(acq,minSize,maxSize,S{1},S{4});
else %red   
    if Height==1024
        acq=I(map.coords{2}(2):map.coords{2}(2)+map.coords{2}(4)-1,map.coords{2}(1):map.coords{2}(1)+map.coords{2}(3)-1);
    else
        acq=I(:,map.coords{2}(1):map.coords{2}(1)+map.coords{2}(3)-1);
    end
    acq=medfilt2(acq,[3 3]);
    [spotcoord]=Localize(acq,minSize,maxSize,S{2},S{4});
end    

tracks(1).coords(1:length(spotcoord)/2,1)=1;
tracks(1).coords(1:length(spotcoord)/2,2)=spotcoord(1:2:end);
tracks(1).coords(1:length(spotcoord)/2,3)=spotcoord(2:2:end);
maxcoord=length(spotcoord)/2;
j=1;
if length(Frames)>1
    sumFrames=sum(Frames(1:2));
else
    sumFrames=Frames;
end    
for i=2:totFrames
    if rem(i,50)==0
        sprintf(formatspec,i,totFrames)
    end   
    if floor(i/Frames(1))==0||i==Frames(1) %for first file   
        I=imread(fullfile(PathName,fileName),i);
    elseif i-sumFrames<0
        I=imread(fullfile(PathName,strcat(fileName(1:end-8),'_',num2str(j,'%d'),'.ome.tif')),i-sum(Frames(1:j)));
    else
        I=imread(fullfile(PathName,strcat(fileName(1:end-8),'_',num2str(j,'%d'),'.ome.tif')),Frames(j+1)); 
        j=j+1;
        if j+1<=length(Frames)
            sumFrames=sumFrames+Frames(j+1);
        end    
    end    
    if strcmp(View,'merged')
        acq=I;
        acq=medfilt2(acq,[3 3]);
        [spotcoord]=Localize(acq,minSize,maxSize,(S{1}+S{2})/2,S{4});
    elseif strcmp(View,'green')
        if Height==1024 %this is the full height in the camera. Should be changed accordingly
            acq=I(map.coords{1}(2):map.coords{1}(2)+map.coords{1}(4)-1,map.coords{1}(1):map.coords{1}(1)+map.coords{1}(3)-1);
        else
            acq=I(:,map.coords{1}(1):map.coords{1}(1)+map.coords{1}(3)-1);
        end
        acq=medfilt2(acq,[3 3]);
        [spotcoord]=Localize(acq,minSize,maxSize,S{1},S{4});
    else %red
        if Height==1024
            acq=I(map.coords{2}(2):map.coords{2}(2)+map.coords{2}(4)-1,map.coords{2}(1):map.coords{2}(1)+map.coords{2}(3)-1);
        else
            acq=I(:,map.coords{2}(1):map.coords{2}(1)+map.coords{2}(3)-1);
        end
        acq=medfilt2(acq,[3 3]);
        [spotcoord]=Localize(acq,minSize,maxSize,S{2},S{4});
    end
    Size=size(acq);
    row=spotcoord(1:2:end);
    col=spotcoord(2:2:end);
    %%%remove false spots from edges%%%
    indrow=find(row<15|row>(Size(2)-15));
    indcol=find(col<15|col>(Size(1)-15));
    indRemove=[indrow*2-1 indrow*2 indcol*2-1 indcol*2];
    indRemove=unique(indRemove);
    spotcoord(indRemove)=[];
    if isempty(spotcoord)
        continue;
    end    
    tracks(1).coords(maxcoord+1:maxcoord+length(spotcoord)/2,1)=i;
    tracks(1).coords(maxcoord+1:maxcoord+length(spotcoord)/2,2)=spotcoord(1:2:end);
    tracks(1).coords(maxcoord+1:maxcoord+length(spotcoord)/2,3)=spotcoord(2:2:end);
    maxcoord=sum(tracks(1).coords(:,1)>0);
end 
%uses a modified version of andreas karrenbauer tracking software for single molecules
[Track]=tracking_new(tracks(1).coords,maxDist,maxFrameStep,NeigbourDist,minTrack,0,'');
numTrack=max(Track(:,4));
tracks(1).coords=zeros(totFrames,numTrack*2);
%reorganizes tracks
for i=1:numTrack
  Ind=Track(:,4)==i;
  Temp=Track(Ind,:);
  IndCurr=Temp(:,3);
  tracks(1).coords(IndCurr,2*i-1:2*i)=Temp(:,1:2);
end  
%%%%%removes false detections at the edge of the image%%%%
edgeInd=zeros(length(tracks(1).coords(1,:)),1);
Size=size(acq);
for i=1:2:length(tracks(1).coords(1,:))
    if mean(tracks(1).coords(tracks(1).coords(:,i)>0,i))<15||mean(tracks(1).coords(tracks(1).coords(:,i)>0,i))>(Size(2)-15)
        edgeInd(i:i+1)=1;
    end
    if mean(tracks(1).coords(tracks(1).coords(:,i+1)>0,i+1))<15||mean(tracks(1).coords(tracks(1).coords(:,i+1)>0,i+1))>(Size(1)-15)
        edgeInd(i:i+1)=1;
    end
end    
tracks(1).coords(:,logical(edgeInd))=[];
save(fullfile(PathName,strcat(fileName(1:end-4),'.tracks2.mat')),'tracks','totFrames','PathName','fileName','View','exptime','-v7.3')    