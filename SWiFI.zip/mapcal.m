%register channels from a movie of a fixed sample to work with SWiFi
% software
function mapcal
%get images file
[fileName,PathName]=uigetfile('*.tif');
%produce total intensity projection image
list=imfinfo(fullfile(PathName,fileName));
totframes=1:length(list);
Itot=0;
% for i=1:10 %currently assumes using bright beads so no summation needed
%     I=imread(fullfile(PathName,fileName),i);
%     Itot=Itot+double(I);
% end    
Itot=imread(fullfile(PathName,fileName));
%display image and define channel boundaries
imshow(medfilt2(Itot, [3 3]),[median(Itot(:)) mean(Itot(:))+2*std(double(Itot(:)))]);
display('choose green channel boundaries');
map.coords{1}(1:4)=round(getrect);
map.coords{1}(map.coords{1}(:)==0)=1;
display('choose red channel boundaries');
map.coords{2}(1:4)=round(getrect);
map.coords{2}(map.coords{2}(:)==0)=1;
%adjust the channel size to coincide
map.coords{1}(3)=min([map.coords{1}(3) map.coords{2}(3)]);
map.coords{2}(3)=map.coords{1}(3);
map.coords{1}(4)=min([map.coords{1}(4) map.coords{2}(4)]);
map.coords{2}(4)=map.coords{1}(4);
%separate the channel images
acqGreen=Itot(map.coords{1}(2):map.coords{1}(2)+map.coords{1}(4)-1,map.coords{1}(1):map.coords{1}(1)+map.coords{1}(3)-1);
acqRed=Itot(map.coords{2}(2):map.coords{2}(2)+map.coords{2}(4)-1,map.coords{2}(1):map.coords{2}(1)+map.coords{2}(3)-1);
%s=size(acqRed);
%%%%%%%%%%%find spots in each channel%%%%%%%%%%
spots(1).coords=mapLoc(acqGreen,2.5); 
spots(2).coords=mapLoc(acqRed,4);
%%%%find the typical distance between close points and define it as the
%%%%colocradius
h=pdist2(spots(1).coords,spots(2).coords);
colocradius=mean(min(h));
if colocradius>10 
    colocradius=10;%if sample is sparse
end    
%%near neighbour filter of 1.5 times the colocradius to eliminate wrong
%%assignments
dG=squareform(pdist(spots(1).coords));
[m,~]=find(dG>0&dG<colocradius*1.5);
spots(1).coords(m,:)=[];
dR=squareform(pdist(spots(2).coords));
[m,~]=find(dR>0&dR<colocradius*1.5);
spots(2).coords(m,:)=[];
%%%%%%determine colocalized spots%%%%
     %calc distance between markers in green and red channels
     dx=repmat(spots(1).coords(:,1),[1,size(spots(2).coords,1)])-repmat(spots(2).coords(:,1)',[size(spots(1).coords,1),1]);
     dy=repmat(spots(1).coords(:,2),[1,size(spots(2).coords,1)])-repmat(spots(2).coords(:,2)',[size(spots(1).coords,1),1]);
     %find colocalized spots only
     [midx,nidx]=find(dx.^2+dy.^2<colocradius^2);
     %remove spots that appear more than once
     [midx,imidx]=unique(midx);
     nidx=nidx(imidx);
     [nidx,inidx]=unique(nidx);
     midx=midx(inidx);
     %%%%assign the colocalized spots
     spots(1).coords=spots(1).coords(midx,:);
     spots(2).coords=spots(2).coords(nidx,:);
     subplot(1,2,1);imshow(acqGreen,[mean(acqGreen(:)),mean(acqGreen(:))+4*std(double(acqGreen(:)))]);
     hold on 
     scatter(spots(1).coords(:,1),spots(1).coords(:,2));
     hold off
     subplot(1,2,2);imshow(acqRed,[mean(acqRed(:)),mean(acqRed(:))+4*std(double(acqRed(:)))]);
     hold on 
     scatter(spots(2).coords(:,1),spots(2).coords(:,2));
     hold off
%%%%%%%define the geometric transformation%%%%%
     map.tformlr=fitgeotrans(double(spots(1).coords),double(spots(2).coords),'polynomial',2);
     map.tformrl=fitgeotrans(double(spots(2).coords),double(spots(1).coords),'polynomial',2);
%%%%%%test the new transformation%%%%%
     figure;
     scatter(spots(1).coords(:,1),spots(1).coords(:,2),'+');
     hold on
     [x,y]=transformPointsInverse(map.tformlr,spots(2).coords(:,1),spots(2).coords(:,2));
     scatter(x,y,'xr');
     hold off
 %%%save map file%%%    
save(fullfile(PathName,'map.mat'),'map');