function spotcoord=mapLoc(I,STD)
%localizes using the centroid method and retrieves the intensity weighted
%centroid, uses a number of STD above mean to segment, and inputs from user
%on area histogram to exclude outliers

BW=I>(mean(I(:))+STD*std(double(I(:))));
s=regionprops(BW,{'Area'});
area=[s.Area];
histogram(area,1:10:max(area));
[x,~]=ginput(2);
BW2=bwareaopen(BW,round(x(1)))&~bwareaopen(BW,round(x(2)));
s=regionprops(BW2,I,{'WeightedCentroid','PixelList'});
if ~isempty(s)
    spots=extractfield(s,'WeightedCentroid');
    spotcoord=[spots(1:2:end)' spots(2:2:end)'];
else
    spotcoord=[];
end


