%% This function analyses tracks produced by either trackUI or trackFRETUI 
%%and calculates diffusion coefficients and hydrodynamic radii

function [particle,pxtot,pytot,D,tracks]= trackAnalysisUI(tracks,Viscosity,Temperature,exptime,Size)
pxSize=117e-9; %117 nm per pixel, change to your calibration 
maxTrack=max(sum(tracks(1).coords~=0,1));
particle(1).Px=zeros(maxTrack,length(tracks(1).coords(1,:))/2);
particle(1).Py=zeros(size(particle(1).Px));
particle(1).Weight=zeros(size(particle(1).Px));
meanX=0;
meanY=0;
edgeInd=zeros(length(tracks(1).coords(1,:)),1);
%remove tracks from edges of FOV (supposedly false detections)
for i=1:2:length(tracks(1).coords(1,:))
    if mean(tracks(1).coords(tracks(1).coords(:,i)>0,i))<10||mean(tracks(1).coords(tracks(1).coords(:,i)>0,i))>(Size(2)-10)
        edgeInd(i:i+1)=1;
    end
    if mean(tracks(1).coords(tracks(1).coords(:,i+1)>0,i+1))<10||mean(tracks(1).coords(tracks(1).coords(:,i+1)>0,i+1))>(Size(1)-10)
        edgeInd(i:i+1)=1;
    end
end    
tracks(1).coords(:,logical(edgeInd))=[];
EdgeInd=edgeInd(1:2:end);
if isfield(tracks(1),'photons')
    tracks(1).photons(:,logical(EdgeInd))=[];
    tracks(2).photons(:,logical(EdgeInd))=[];
    tracks(1).eFRET(:,logical(EdgeInd))=[];
end
for i=1:length(tracks(1).coords(1,:))/2
    Px=[];
    Py=[];
    Weight=[];
    particle(i).coords=tracks(1).coords(:,2*i-1:2*i);
    Ind=find(tracks(1).coords(:,2*i));
    stepLength=diff(Ind);
    %calculates diffusion based on the lag between frames (not always 1!)
    particle(i).D=mean(((diff(tracks(1).coords(Ind(1:end-1),2*i-1)).^2*pxSize^2)+(diff(tracks(1).coords(Ind(1:end-1),2*i)).^2*pxSize^2))./(4*stepLength(1:end-1)*exptime));%D=MSD/4ndt, n-frame gap
    particle(i).R=1.38E-23*(Temperature+273.15)/(6*pi*Viscosity*particle(i).D);%R=KBT/6*pi*eta*D
    for j=1:length(Ind)-1
        indJ=(Ind(j+1:end)-Ind(1:end-j))==j;
        if ~any(find(indJ))
            break
        end    
        Weight(j)=sum(indJ);
        Px(j)=mean((tracks(1).coords(Ind(indJ)+j,2*i-1)-tracks(1).coords(Ind(indJ),2*i-1)).^2*pxSize^2);%calculates P(n)=mean(sum((Xk+n-Xk)^2)
        Py(j)=mean((tracks(1).coords(Ind(indJ)+j,2*i)-tracks(1).coords(Ind(indJ),2*i)).^2*pxSize^2);
    end    
    particle(1).Px(1:length(Px),i)=Px;
    particle(1).Py(1:length(Px),i)=Py;
    particle(1).Weight(1:length(Px),i)=Weight;
end    
%%% remove stagnant particles %%%
D=extractfield(particle,'D');
Px=particle(1).Px;
Py=particle(1).Py;
Weight=particle(1).Weight;
%%%remove static particles/very large aggregates
indD=D>1e-14;
D=D(indD);
falseind=2*find(~indD);
falseindarray=zeros(length(falseind)*2,1);
falseindarray(1:2:end)=falseind-1;
falseindarray(2:2:end)=falseind;
particle(~indD)=[];
tracks(1).coords(:,falseindarray)=[];
particle(1).Weight=Weight(:,indD);
particle(1).Px=Px(:,indD);
particle(1).Py=Py(:,indD);
%%find track length weighted mean diffusion value
meanD=0;
for i=1:sum(indD)
    meanD=meanD+D(i)*particle(1).Weight(1,i);
end
%diffusion coefficient weighted by track length
particle(1).meanD=meanD/sum(particle(1).Weight(1,:));
particle(1).diameter=2*1.38E-23*(Temperature+273.15)/(6*pi*Viscosity*particle(1).meanD);
%%remove empty fields (tracks shorter than minimum)
emptyIndex = find(arrayfun(@(particle) isempty(particle.D),particle));
emptyIndex(emptyIndex==1)=[];
particle(emptyIndex)=[];
%calculates P(n)=mean(sum((Xk+n-Xk)^2)=2Dndt+(2sigma^2-4/6Ddt) -from Berglund, Andrew J. "Statistics of camera-based single-particle tracking." Physical Review E 82.1 (2010): 011917.
N=max(sum(particle(1).Px~=0,1));
for i=1:N
    pxtot(i)=mean(particle(1).Px(i,particle(1).Px(i,:)~=0));
    pytot(i)=mean(particle(1).Py(i,particle(1).Px(i,:)~=0));
end

