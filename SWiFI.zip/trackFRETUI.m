%%this function tracks FRET of spots in solution based on the centroid
%%method. it uses a map.mat file to register the channels
%%in alex mode it assumes the non even frames to be green excitation
%%maxDist-maximum distance between spots that belong to the same track
%%between frames
%%NieghbourDist- nearset neighbour filter criterion
%%minSize,maxSize-minimum and maximum sizes of spots to include
%%S-threhold sensitivity for adaptive thresholding. usually values between
%%0.55-0.58 work best. experiment related.
%%Mode-'continous [1]' or 'alex [2]'
%%type- type of file system
%%trackLength- minimum track length in localiztions. i.e. 3 means 2 steps
function [tracks]= trackFRETUI(fileName,PathName,maxDist,NeighbourDist,minSize,maxSize,S,Mode,totFrames,Frames,type,map,trackLength)
fileList=dir(fullfile(PathName,strcat(fileName(1:end-4),'*.tif')));
numFile=length(fileList);
list.info=imfinfo(fullfile(PathName,fileName));
Height=list.info.Height;
midxR=[];
midxG=[];
coLocInd=[];
coLocFRET=[];
View='merged';
flag=[];
formatspec='This is frame %d out of %d';
tracks(1).photons=zeros(totFrames,6000);
tracks(2).photons=zeros(totFrames,6000);
tracks(1).eFRET=zeros(totFrames,6000);
tracks(1).sto=zeros(totFrames,6000);
tracks(1).coords=zeros(totFrames,12000);%allows up to 6000 seperate tracks

%initialize data by finding molecules in the first frame (green excitation
%assumed)
I=imread(fullfile(PathName,fileName),1);
if Height<1024
    acqGreen=I(:,map.coords{1}(1):map.coords{1}(1)+map.coords{1}(3)-1);
else    
    acqGreen=I(map.coords{1}(2):map.coords{1}(2)+map.coords{1}(4)-1,map.coords{1}(1):map.coords{1}(1)+map.coords{1}(3)-1);
end    
Size=size(acqGreen); 
%find spots in green channel
acqGreen=medfilt2(acqGreen,[3 3]);
[spotG,photonG,~,sG]=Localize(acqGreen,minSize,maxSize,S{1},S{4});
spotcoordGC=[spotG(1:2:end)' spotG(2:2:end)'];
%%remove false detections at edges of image
indFalse=find(spotcoordGC(:,1)<15|spotcoordGC(:,2)<15|length(acqGreen(:,1))-30<spotcoordGC(:,1)|length(acqGreen(:,2))-15<spotcoordGC(:,2));
spotcoordGC(indFalse,:)=[];
photonG(indFalse)=[];
sG(indFalse)=[];
if Height<1024
    acqRed=I(:,map.coords{2}(1):map.coords{2}(1)+map.coords{2}(3)-1);
else    
    acqRed=I(map.coords{2}(2):map.coords{2}(2)+map.coords{2}(4)-1,map.coords{2}(1):map.coords{2}(1)+map.coords{2}(3)-1);
end    
%finds spots in red channel
acqRed=medfilt2(acqRed,[3 3]);
[spotR,photonR,~,sR]=Localize(acqRed,minSize,maxSize,S{2},S{4}); 
if isempty(spotR)
    tracks(1).coords(1,1:2:2*length(spotcoordGC(:,1)))=spotcoordGC(:,1);
    tracks(1).coords(1,2:2:2*length(spotcoordGC(:,1)))=spotcoordGC(:,2);
    tracks(1).photons(1,1:length(photonG))=photonG;
    maxcoord=length(spotG);
elseif isempty(spotG)
    %rotate the red channel to fit the green coordinates
    [Xr,Yr]=transformPointsInverse(map.tformlr,spotR(1:2:end),spotR(2:2:end));
    spotcoordRC=[Xr' Yr'];
    %%remove false detections at edges of image
    indFalse=find(spotcoordRC(:,1)<15|spotcoordRC(:,2)<20|length(acqRed(:,1))-30<spotcoordRC(:,1)|length(acqRed(:,2))-15<spotcoordRC(:,2));
    spotcoordRC(indFalse,:)=[];
    photonR(indFalse)=[];
    sR(indFalse)=[];
    coordR=zeros(2*length(photonR),1);
    coordR(1:2:end)=spotcoordRC(:,1);
    coordR(2:2:end)=spotcoordRC(:,1);
    tracks(1).coords(1,1:length(coordR))=coordR;
    tracks(2).photons(1:length(photonR))=photonR;
    maxcoord=length(spotR);
else  
    %rotate the red channel to fit the green coordinates (uses polynomial
    %2D tranforamtion)
    [Xr,Yr]=transformPointsInverse(map.tformlr,spotR(1:2:end),spotR(2:2:end));
    spotcoordRC=[Xr' Yr'];
    indFalse=find(spotcoordRC(:,1)<10|spotcoordRC(:,1)>(length(acqRed(1,:))-30)|spotcoordRC(:,2)<10|spotcoordRC(:,2)>(length(acqRed(:,1))-10)); 
    spotcoordRC(indFalse,:)=[];
    photonR(indFalse)=[];
    sR(indFalse)=[];
    %find colocalized spots
    D=pdist2(spotcoordGC,spotcoordRC);
    idxmatrix=D<=2; %maximum 2 pixel difference in position
    [midx,nidx]=find(idxmatrix);
    %use green channel coordinates for colocalized spots (since we use the green channel as the channel of reference)
    tracks(1).coords(1,1:2:2*length(midx))=spotcoordGC(midx,1);
    tracks(1).coords(1,2:2:2*length(midx))=spotcoordGC(midx,2);
    %add photon values of colocalized spots
    tracks(1).photons(1,1:length(midx))=photonG(midx);
    tracks(2).photons(1,1:length(nidx))=photonR(nidx);
    %add remaining spots
    indrest=true(length(photonG),1);
    indrest(midx)=0;
    indrest=find(indrest);
    tracks(1).coords(1,2*length(midx)+1:2:2*length(spotcoordGC(:,1)))=spotcoordGC(indrest,1);
    tracks(1).coords(1,2*length(midx)+2:2:2*length(spotcoordGC(:,1)))=spotcoordGC(indrest,2);
    %add green spots and corresponding red spots
    for j=1:length(indrest)
        %get the pixels used to calculate the green intensity
        cY=sG(indrest(j)).PixelList(:,2);
        cX=sG(indrest(j)).PixelList(:,1);
        %make sure the boundaries are within the image
        if min(cX)>2
            minCx=min(cX);
        else
            minCx=3;
        end
        if max(cX)<Size(2)-2
            maxCx=max(cX);
        else
            maxCx=Size(2)-2;
        end
        if min(cY)>2
            minCy=min(cY);
        else
            minCy=3;
        end
        if max(cY)<Size(1)-2
            maxCy=max(cY);
        else
            maxCy=Size(1)-2;
        end
        %get equivalent red coordinates
        [Xr,Yr]=transformPointsInverse(map.tformrl,cX,cY);
        cXr=round(Xr);
        cYr=round(Yr);
        minCxr=min(cXr);
        minCyr=min(cYr);
        maxCxr=max(cXr);
        maxCyr=max(cYr);
        %make sure new coordinates are within the channel
        if max(cXr)>Size(2)-2||max(cYr)>Size(1)-2||min(cXr)<3||min(cYr)<3
            tracks(1).coords(1,find(tracks(1).coords(1,:)==sG(indrest(j)).WeightedCentroid(1)):find(tracks(1).coords(1,:)==sG(indrest(j)).WeightedCentroid(1))+1)=0;
            continue
        else
            %find background coordinates
            pind=sub2ind(size(acqRed),cYr,cXr);
            bgG=acqGreen(minCy-2:maxCy+2,minCx-2:maxCx+2);
            bgG(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
            bgR=acqRed(minCyr-2:maxCyr+2,minCxr-2:maxCxr+2);
            bgR(3:3+maxCyr-minCyr,3:3+maxCxr-minCxr)=0;
            %use the equivalent positions in the red channel to
            %calculate the red intensity
            tracks(1).photons(1,length(midx)+j)=(photonG(indrest(j))-mean(bgG(bgG>0)))*sG(indrest(j)).Area;
            tracks(2).photons(1,length(midx)+j)=(mean(acqRed(pind))-mean(bgR(bgR>0)))*sG(indrest(j)).Area;
        end
    end
    %%%%add red spots and corresponding green spots
    %add red spots
    indrest=true(length(photonR),1);
    indrest(nidx)=0;
    indrest=find(indrest);
    maxcoorD=sum(tracks(1).coords(1,:)~=0);
    tracks(1).coords(1,maxcoorD+1:2:maxcoorD+2*length(indrest))=spotcoordRC(indrest,1);
    tracks(1).coords(1,maxcoorD+2:2:maxcoorD+2*length(indrest))=spotcoordRC(indrest,2);
    %add corresponding green spots
    maxSpot=sum(tracks(1).photons(1,:)~=0);
    for j=1:length(indrest)
        %get the pixels used to calculate the green intensity
        cY=sR(indrest(j)).PixelList(:,2);
        cX=sR(indrest(j)).PixelList(:,1);
        %make sure the boundaries are within the image
        if min(cX)>2
            minCx=min(cX);
        else
            minCx=3;
        end
        if max(cX)<Size(2)-2
            maxCx=max(cX);
        else
            maxCx=Size(2)-2;
        end
        if min(cY)>2
            minCy=min(cY);
        else
            minCy=3;
        end
        if max(cY)<Size(1)-2
            maxCy=max(cY);
        else
            maxCy=Size(1)-2;
        end
        %get equivalent green coordinates
        [Xg,Yg]=transformPointsInverse(map.tformlr,cX,cY);
        cXg=round(Xg);
        cYg=round(Yg);
        minCxg=min(cXg);
        minCyg=min(cYg);
        maxCxg=max(cXg);
        maxCyg=max(cYg);
        %make sure new coordinates are within the channel, and if not
        %remove the track
        if max(cXg)>Size(2)-2||max(cYg)>Size(1)-2||min(cXg)<3||min(cYg)<3         
            tracks(1).coords(1,find(tracks(1).coords(1,:)==sR(indrest(j)).WeightedCentroid(1)):find(tracks(1).coords(1,:)==sR(indrest(j)).WeightedCentroid(1))+1)=0;
            continue
        else
            %find background coordinates
            pind=sub2ind(size(acqGreen),cYg,cXg);
            bgR=acqRed(minCy-2:maxCy+2,minCx-2:maxCx+2);
            bgR(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
            bgG=acqGreen(minCyg-2:maxCyg+2,minCxg-2:maxCxg+2);
            bgG(3:3+maxCyg-minCyg,3:3+maxCxg-minCxg)=0;
            %use the equivalent positions in the red channel to
            %calculate the red intensity
            tracks(2).photons(1,maxSpot+j)=(photonR(indrest(j))-mean(bgR(bgR>0)))*sR(indrest(j)).Area;
            tracks(1).photons(1,maxSpot+j)=(mean(acqGreen(pind))-mean(bgG(bgG>0)))*sR(indrest(j)).Area;
        end
    end
    maxcoord=sum(tracks(1).coords(1,:)~=0);
end
%find tracks and intensities
k=1;
midCo=[];
for i=2:totFrames
    spotR=[];
    spotG=[];
    indspotG=[];
    indspotR=[];
    spotcoordGC=[];
    spotcoordRC=[];
    if rem(i,50)==0
        sprintf(formatspec,i,totFrames)
    end
    if k>1
        if strcmp(type,'nim2')
            I=imread(fullfile(PathName,strcat(fileName(1:end-8),'_',num2str(k-1,'%d'),'.ome.tif')),i-sum(Frames(1:k-1)));
        else
            I=imread(fullfile(PathName,strcat(fileName(1:end-4),'_',num2str(k-1,'%d'),'.tif')),i-sum(Frames(1:k-1)));
        end
    else
        I=imread(fullfile(PathName,fileName),i);
    end
    if i==sum(Frames(1:k))
        k=k+1;
    end        
    %assumes first frame to be green excitation
  if (rem(i,2)~=0&&Mode==2)||Mode~=2
      if Height<1024
          acqGreen=I(:,map.coords{1}(1):map.coords{1}(1)+map.coords{1}(3)-1);
      else
          acqGreen=I(map.coords{1}(2):map.coords{1}(2)+map.coords{1}(4)-1,map.coords{1}(1):map.coords{1}(1)+map.coords{1}(3)-1);
      end
    acqGreen=medfilt2(acqGreen,[3 3]);
    [spotG,photonG,~,sG]=Localize(acqGreen,minSize,maxSize,S{1},S{4});
    indspotG=1:length(photonG);
    %nearest neighbour filter
    if ~isempty(spotG)
        spotcoordGC=[spotG(1:2:end)' spotG(2:2:end)'];
        nG=numel(spotcoordGC)/2;
        idx1DG=find(pdist(spotcoordGC)<=NeighbourDist);
        idx2DG=ceil(nG-0.5-sqrt((nG-0.5)^2-2*idx1DG));
        spotcoordGC(idx2DG,:)=[];
        indspotG(idx2DG)=[];
        photonG(idx2DG)=[];
        %remove false positives arising at the 4 edges of the image
        indFalse=find(spotcoordGC(:,1)<20|spotcoordGC(:,1)>(length(acqGreen(1,:))-30)|spotcoordGC(:,2)<15|spotcoordGC(:,2)>(length(acqGreen(:,1))-15));
        spotcoordGC(indFalse,:)=[];
        indspotG(indFalse)=[];
        photonG(indFalse)=[];
    end
  end
  if Height<1024
      acqRed=I(:,map.coords{2}(1):map.coords{2}(1)+map.coords{2}(3)-1);
  else
      acqRed=I(map.coords{2}(2):map.coords{2}(2)+map.coords{2}(4)-1,map.coords{2}(1):map.coords{2}(1)+map.coords{2}(3)-1);
  end
  acqRed=medfilt2(acqRed,[3 3]);
    if (rem(i,2)~=0&&Mode==2)||Mode~=2
        [spotR,photonR,~,sR]=Localize(acqRed,minSize,maxSize,S{2},S{4});
    else
        [spotR,photonR,~,sR]=Localize(acqRed,minSize,maxSize,S{3},S{4});
    end    
    indspotR=1:length(photonR);
    if isempty(spotG)&&isempty(spotR)
        continue
    end
    spotcoordRC=[spotR(1:2:end)' spotR(2:2:end)'];
    %nearest neighbour filter
    if ~isempty(spotR)        
        nR=numel(spotcoordRC)/2;
        idx1DR=find(pdist(spotcoordRC)<=NeighbourDist);
        idx2DR=ceil(nR-0.5-sqrt((nR-0.5)^2-2*idx1DR));
        spotcoordRC(idx2DR,:)=[];
        indspotR(idx2DR)=[];
        photonR(idx2DR)=[];
        [Xr,Yr]=transformPointsInverse(map.tformlr,spotcoordRC(:,1),spotcoordRC(:,2));
        spotcoordRC(:,1)=Xr;
        spotcoordRC(:,2)=Yr;
        %remove false positives arising at the 4 edges of the image
        indFalse=find(spotcoordRC(:,1)<20|spotcoordRC(:,1)>(length(acqRed(1,:))-30)|spotcoordRC(:,2)<15|spotcoordRC(:,2)>(length(acqRed(:,1))-15));
        spotcoordRC(indFalse,:)=[];
        indspotR(indFalse)=[];
        photonR(indFalse)=[];
    end
%find spots that belong to existing tracks
    midxR=[];nidxR=[];
    midxG=[];nidxG=[];
    IndPre=tracks(1).coords(i-1,tracks(1).coords(i-1,:)~=0);
    Xexc=find(IndPre(1:2:end)<2|IndPre(1:2:end)>Size(2)-2); %exclude tracks that are too close to the edges
    Yexc=find(IndPre(2:2:end)<2|IndPre(2:2:end)>Size(1)-2); %exclude tracks that are too close to the edges
    IndPre(2*(Xexc-1)+1:2*(Xexc-1)+2)=0;
    IndPre(2*Yexc-1:2*Yexc)=0;
    IndPre(IndPre==0)=[];
    ind=find(tracks(1).coords(i-1,:)>0);
    ind(2*(Xexc-1)+1:2*(Xexc-1)+2)=0;
    ind(2*Yexc-1:2*Yexc)=0;
    ind(ind==0)=[];
    ind=ind(1:2:end);
    X=IndPre(1:2:end);
    Y=IndPre(2:2:end);
    Traks=[X' Y'];    
    %find tracks in green
    if (rem(i,2)~=0&&Mode==2)||Mode~=2
        if ~isempty(spotcoordGC)
            DG=pdist2(Traks,spotcoordGC);
            idxmatrixG=DG<=maxDist;
            [midxG,nidxG]=find(idxmatrixG);
            %remove spots where two tracks share a spot
            if ~isempty(midxG)
                [midxG,imG,~] = unique(midxG,'stable');
                nidxG=nidxG(imG);
                %remove spots where two spots share a track
                [nidxG,inG,~] = unique(nidxG,'stable');
                midxG=midxG(inG);
            end
        end
    end
    %find tracks in red
    if ~isempty(spotcoordRC)
        DR=pdist2(Traks,spotcoordRC);
        idxmatrixR=DR<=maxDist;
        [midxR,nidxR]=find(idxmatrixR);
        %remove spots where two tracks share a spot
        if ~isempty(midxR)
            [midxR,imR,~] = unique(midxR,'stable');
            nidxR=nidxR(imR);
            %remove spots where two spots share a track
            [nidxR,inR,~] = unique(nidxR,'stable');
            midxR=midxR(inR);
        end    
    end 
    %intialize colocalized indices
    nidCoR=[];
    nidCoG=[];
    midCo=[];
    %find colocalized spots
    if ~isempty(midxR)&& ~isempty(midxG)
        if ~isempty(intersect(midxR,midxG))
            %define tracks with colocoalized spots
            [~,indSameR,indSameG]=intersect(midxR,midxG);
            midCo=midxR(indSameR);
            nidCoR=nidxR(indSameR);
            nidCoG=nidxG(indSameG);
            %define tracks without colocalization            
            midx=[midCo;setdiff(midxR,midxR(indSameR),'stable');setdiff(midxG,midxR(indSameR),'stable')];
            %add all the red spots, and also all the green spots that do not overlap with the red
            spotcoordC=[spotcoordRC(nidCoR,:);spotcoordRC(setdiff(nidxR,nidxR(indSameR),'stable'),:);spotcoordGC(setdiff(nidxG,nidxG(indSameG),'stable'),:)]; 
        else
            midCo=[];
            nidCoR=[];
            nidCoG=[];
            midx=[midxR;midxG];
            spotcoordC=[spotcoordRC(nidxR,:); spotcoordGC(nidxG,:)];
        end                   
    elseif isempty(midxR)&&~isempty(spotG) %only green
        midx=midxG;
        spotcoordC=spotcoordGC;
        nidx=nidxG;
        flag='green';
    elseif ~isempty(spotR)        %only red
        midx=midxR;
        spotcoordC=spotcoordRC;
        nidx=nidxR;
        flag='red';
    end    
    %add new spots to existing tracks
    if ~isempty(midx)
        ind=ind(midx);
        if ~isempty(midxR)&& ~isempty(midxG)
            tracks(1).coords(i,ind)=spotcoordC(:,1);
            tracks(1).coords(i,ind+1)=spotcoordC(:,2);
        else
            tracks(1).coords(i,ind)=spotcoordC(nidx,1);
            tracks(1).coords(i,ind+1)=spotcoordC(nidx,2);
        end
    end   
    %discard tracks with a few frames
    tempCoord=sum(tracks(1).coords(1:i-1,:)~=0,1);
    maxcoord=find(tempCoord, 1, 'last' );
    if isempty(maxcoord)
        maxcoord=0;
    end    
    if rem(i,50)==0 % keep tracks longer than 2 and the current active tracks
        tempCoord=(tempCoord>=trackLength)|(tracks(1).coords(i,:)>0);
    else
        tempCoord=[];
    end
    if ~isempty(tempCoord)
        coLocTemp=[];
        tracks(1).coords(:,1:sum(tempCoord))=tracks(1).coords(:,tempCoord);
        tracks(1).coords(:,sum(tempCoord)+1:end)=0;
        photonCoord=find(tempCoord);
        photonCoord=photonCoord(2:2:end)/2;
        tracks(1).photons(:,1:length(photonCoord))=tracks(1).photons(:,photonCoord);
        tracks(2).photons(:,1:length(photonCoord))=tracks(2).photons(:,photonCoord);
        tracks(1).photons(:,length(photonCoord)+1:end)=0;
        tracks(2).photons(:,length(photonCoord)+1:end)=0;
        %%%remove short tracks from list of colocalized spots
        if ~isempty(coLocInd)
            for j=1:length(photonCoord)
                coInd=find(coLocInd(:,2)==photonCoord(j));
                coLocTemp=[coLocTemp; [coLocInd(coInd,1) j*ones(length(coInd),1)]];
            end
        coLocInd=coLocTemp;
        end
        maxcoord=sum(tempCoord);
    end
    %add intensities to current tracks
    CurrInd=find(tracks(1).coords(i,:)>0);
    CurrIndPhoton=CurrInd(2:2:end)/2;
    if ~isempty(CurrInd)
        CurrCoord=[tracks(1).coords(i,CurrInd(1:2:end))' tracks(1).coords(i,CurrInd(2:2:end))'];
        if (rem(i,2)~=0&&Mode==2)||Mode~=2
            %add coloclalized spots
            if ~isempty(midCo)
                spotCo=spotcoordRC(nidCoR,:);
                %find the coloclaized spots in the current frame's coordinates
                currCo=pdist2(CurrCoord,spotCo);
                [mCo,~]=find(currCo==0);
                %assign intensities to corresponding tracks
                for j=1:length(midCo)
                    %get the pixels used to calculate the green intensity
                    cY=sG(indspotG(nidCoG(j))).PixelList(:,2);
                    cX=sG(indspotG(nidCoG(j))).PixelList(:,1);
                    %make sure the boundaries are within the image
                    if min(cX)>2
                        minCx=min(cX);
                    else
                        minCx=3;
                    end
                    if max(cX)<Size(2)-2
                        maxCx=max(cX);
                    else
                        maxCx=Size(2)-2;
                    end
                    if min(cY)>2
                        minCy=min(cY);
                    else
                        minCy=3;
                    end
                    if max(cY)<Size(1)-2
                        maxCy=max(cY);
                    else
                        maxCy=Size(1)-2;
                    end
                    %find background coordinates
                    bgG=acqGreen(minCy-2:maxCy+2,minCx-2:maxCx+2);
                    bgG(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                    %add intensity values to green spots
                    tracks(1).photons(i,CurrIndPhoton(mCo(j)))=(photonG(nidCoG(j))-mean(bgG(bgG>0)))*sG(indspotG(nidCoG(j))).Area;
                    coLocInd=[coLocInd; [i CurrIndPhoton(mCo(j))]];
                    %%%%%%%
                    %get the pixels used to calculate the red intensity
                    cY=sR(indspotR(nidCoR(j))).PixelList(:,2);
                    cX=sR(indspotR(nidCoR(j))).PixelList(:,1);
                    %make sure the boundaries are within the image
                    if min(cX)>2
                        minCx=min(cX);
                    else
                        minCx=3;
                    end
                    if max(cX)<Size(2)-2
                        maxCx=max(cX);
                    else
                        maxCx=Size(2)-2;
                    end
                    if min(cY)>2
                        minCy=min(cY);
                    else
                        minCy=3;
                    end
                    if max(cY)<Size(1)-2
                        maxCy=max(cY);
                    else
                        maxCy=Size(1)-2;
                    end
                    %find background coordinates
                    bgR=acqRed(minCy-2:maxCy+2,minCx-2:maxCx+2);
                    bgR(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                    %add intensity values to green spots
                    tracks(2).photons(i,CurrIndPhoton(mCo(j)))=(photonR(nidCoR(j))-mean(bgR(bgR>0)))*sR(indspotR(nidCoR(j))).Area;
                    coLocFRET=[coLocFRET tracks(2).photons(i,CurrIndPhoton(mCo(j)))/(tracks(2).photons(i,CurrIndPhoton(mCo(j)))+tracks(1).photons(i,CurrIndPhoton(mCo(j))))];
                end
            end
            %%%%%%%add green spots
            if ~isempty(nidCoG)
                nidxG=setdiff(nidxG,nidCoG);
            end
            if ~isempty(nidxG)
                spotCG=spotcoordGC(nidxG,:);
                %find the green spots in the current frame's coordinates
                currG=pdist2(CurrCoord,spotCG);
                idxG=currG==0;
                [mG,~]=find(idxG);
                %assign green spots to their corresponding tracks
                for j=1:length(mG)
                    %get the pixels used to calculate the green intensity
                    cY=sG(indspotG(nidxG(j))).PixelList(:,2);
                    cX=sG(indspotG(nidxG(j))).PixelList(:,1);
                    %make sure the boundaries are within the image
                    if min(cX)>2
                        minCx=min(cX);
                    else
                        minCx=3;
                    end
                    if max(cX)<Size(2)-2
                        maxCx=max(cX);
                    else
                        maxCx=Size(2)-2;
                    end
                    if min(cY)>2
                        minCy=min(cY);
                    else
                        minCy=3;
                    end
                    if max(cY)<Size(1)-2
                        maxCy=max(cY);
                    else
                        maxCy=Size(1)-2;
                    end
                    %get equivalent red coordinates
                    [Xr,Yr]=transformPointsInverse(map.tformrl,cX,cY);
                    cXr=round(Xr);
                    cYr=round(Yr);
                    minCxr=min(cXr);
                    minCyr=min(cYr);
                    maxCxr=max(cXr);
                    maxCyr=max(cYr);
                    %make sure new coordinates are within the channel
                    if max(cXr)>Size(2)-2||max(cYr)>Size(1)-2||min(cXr)<3||min(cYr)<3
                        tracks(1).coords(i,find(tracks(1).coords(i,:)==sG(indspotG(nidxG(j))).WeightedCentroid(1)):find(tracks(1).coords(i,:)==sG(indspotG(nidxG(j))).WeightedCentroid(1))+1)=0;
                        continue
                    else
                        %find background coordinates
                        pind=sub2ind(size(acqRed),cYr,cXr);
                        bgG=acqGreen(minCy-2:maxCy+2,minCx-2:maxCx+2);
                        bgG(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                        bgR=acqRed(minCyr-2:maxCyr+2,minCxr-2:maxCxr+2);
                        bgR(3:3+maxCyr-minCyr,3:3+maxCxr-minCxr)=0;
                        %use the equivalent positions in the red channel to
                        %calculate the red intensity
                        tracks(1).photons(i,CurrIndPhoton(mG(j)))=(photonG(nidxG(j))-mean(bgG(bgG>0)))*sG(indspotG(nidxG(j))).Area;
                        tracks(2).photons(i,CurrIndPhoton(mG(j)))=(mean(acqRed(pind))-mean(bgR(bgR>0)))*sG(indspotG(nidxG(j))).Area;
                    end
                end
            end
        end
        %add red spots and green values corresponding to red spots (or
        %just red spots if measuring AA signal)
        if ~isempty(nidCoR)
            nidxR=setdiff(nidxR,nidCoR);
        end
        if ~isempty(nidxR)
            spotCR=spotcoordRC(nidxR,:);
            currR=pdist2(CurrCoord,spotCR);
            idxR=currR==0;
            [mR,~]=find(idxR);
            for j=1:length(nidxR)
                cY=sR(indspotR(nidxR(j))).PixelList(:,2);
                cX=sR(indspotR(nidxR(j))).PixelList(:,1);
                %make sure the boundaries are within the image
                if min(cX)>2
                    minCx=min(cX);
                else
                    minCx=3;
                end
                if max(cX)<Size(2)-2
                    maxCx=max(cX);
                else
                    maxCx=Size(2)-2;
                end
                if min(cY)>2
                    minCy=min(cY);
                else
                    minCy=3;
                end
                if max(cY)<Size(1)-2
                    maxCy=max(cY);
                else
                    maxCy=Size(1)-2;
                end
                if (rem(i,2)~=0&&Mode==2)||Mode~=2
                    %get equivalent green coordinates
                    [Xg,Yg]=transformPointsInverse(map.tformlr,cX,cY);
                    cXg=round(Xg);
                    cYg=round(Yg);
                    minCxg=min(cXg);
                    minCyg=min(cYg);
                    maxCxg=max(cXg);
                    maxCyg=max(cYg);
                    if max(cXg)>Size(2)-2||max(cYg)>Size(1)-2||min(cXg)<3||min(cYg)<3
                        continue
                    else
                        pind=sub2ind(size(acqGreen),cYg,cXg);
                        bgG=acqGreen(minCyg-2:maxCyg+2,minCxg-2:maxCxg+2);
                        bgG(3:3+maxCyg-minCyg,3:3+maxCxg-minCxg)=0;
                        tracks(1).photons(i,CurrIndPhoton(mR(j)))=(mean(acqGreen(pind))-mean(bgG(bgG>0)))*sR(indspotR(nidxR(j))).Area;
                    end
                end
                bgR=acqRed(minCy-2:maxCy+2,minCx-2:maxCx+2);
                bgR(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                tracks(2).photons(i,CurrIndPhoton(mR(j)))=(photonR(nidxR(j))-mean(bgR(bgR>0)))*sR(indspotR(nidxR(j))).Area;
                
            end
        end
    end
%add new spots to new tracks 
    photonsR=[];
    photonsG=[];
    mRG=[];
    if ~isempty(spotcoordRC)
        idR=ones(length(spotcoordRC(:,1)),1);
        idR(nidxR)=0;
        idR(nidCoR)=0;
        idR=find(idR);
    else
        idR=[];
    end    
    if ~isempty(spotcoordGC)
        idG=ones(length(spotcoordGC(:,1)),1);
        idG(nidxG)=0;
        idG(nidCoG)=0;
        idG=find(idG);
    else
        idG=[];
    end    
    if isempty(idR)&& isempty(idG)
        continue
    elseif isempty(idR)
        flag='green';
    else
        flag='red';
    end
    if ~isempty(idR)&& ~isempty(idG)
        newspotRC=spotcoordRC(idR,:);
        newspotGC=spotcoordGC(idG,:);
        %find colocalized spots and assign their intensities
        RG=pdist2(newspotRC,newspotGC);
        CoRG=RG<=3; %minimum allowed distance due to drift and registration error
        [mRG,nRG]=find(CoRG);
        newspots=newspotGC(nRG,:);
        newspotGC(nRG,:)=[];
        newspotRC(mRG,:)=[];
        newspots=[newspots; newspotGC; newspotRC];
        if ~isempty(nRG)
            %add intensity values of colocalized spots
            for j=1:length(mRG)
                %add red values
                cY=sR(indspotR(idR(mRG(j)))).PixelList(:,2);
                cX=sR(indspotR(idR(mRG(j)))).PixelList(:,1);
                minCx=min(cX);
                minCy=min(cY);
                maxCx=max(cX);
                maxCy=max(cY);
                bgR=acqRed(minCy-2:maxCy+2,minCx-2:maxCx+2);
                bgR(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                photonsR(j)=(photonR(idR(mRG(j)))-mean(bgR(bgR>0)))*sR(indspotR(idR(j))).Area;
                %add green values
                cY=sG(indspotG(idG(nRG(j)))).PixelList(:,2);
                cX=sG(indspotG(idG(nRG(j)))).PixelList(:,1);
                minCx=min(cX);
                minCy=min(cY);
                maxCx=max(cX);
                maxCy=max(cY);
                bgG=acqGreen(minCy-2:maxCy+2,minCx-2:maxCx+2);
                bgG(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                photonsG(j)=(photonG(idG(nRG(j)))-mean(bgG(bgG>0)))*sG(indspotG(idG(j))).Area;
            end
            coLocFRET=[coLocFRET photonsR./(photonsR+photonsG)];
        end
            idG(nRG)=[];
            idR(mRG)=[];
            %%%%add the remaining intensity values
            %add values of green spots
            for j=1:length(idG)
                cY=sG(indspotG(idG(j))).PixelList(:,2);
                cX=sG(indspotG(idG(j))).PixelList(:,1);
                %make sure the boundaries are within the image
                if min(cX)>2
                    minCx=min(cX);
                else
                    minCx=3;
                end
                if max(cX)<Size(2)-2
                    maxCx=max(cX);
                else
                    maxCx=Size(2)-2;
                end
                if min(cY)>2
                    minCy=min(cY);
                else
                    minCy=3;
                end
                if max(cY)<Size(1)-2
                    maxCy=max(cY);
                else
                    maxCy=Size(1)-2;
                end
                %get equivalent red coordinates
                [Xr,Yr]=transformPointsInverse(map.tformrl,cX,cY);
                cXr=round(Xr);
                cYr=round(Yr);
                minCxr=min(cXr);
                minCyr=min(cYr);
                maxCxr=max(cXr);
                maxCyr=max(cYr);
                if max(cXr)>Size(2)-2||max(cYr)>Size(1)-2||min(cXr)<3||min(cYr)<3
                    continue
                else
                    bgR=acqRed(minCyr-2:maxCyr+2,minCxr-2:maxCxr+2);
                    bgR(3:3+maxCyr-minCyr,3:3+maxCxr-minCxr)=0;
                    bgG=acqGreen(minCy-2:maxCy+2,minCx-2:maxCx+2);
                    bgG(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                    pind=sub2ind(size(acqRed),cYr,cXr);
                    photonsR=[photonsR (mean(acqRed(pind))-mean(bgR(bgR>0)))*sG(indspotG(idG(j))).Area];
                    photonsG=[photonsG (photonG(idG(j))-mean(bgG(bgG>0)))*sG(indspotG(idG(j))).Area];
                end
            end
            %get values of red spots
            for j=1:length(idR)
                cY=sR(indspotR(idR(j))).PixelList(:,2);
                cX=sR(indspotR(idR(j))).PixelList(:,1);
                %make sure the boundaries are within the image
                if min(cX)>2
                    minCx=min(cX);
                else
                    minCx=3;
                end
                if max(cX)<Size(2)-2
                    maxCx=max(cX);
                else
                    maxCx=Size(2)-2;
                end
                if min(cY)>2
                    minCy=min(cY);
                else
                    minCy=3;
                end
                if max(cY)<Size(1)-2
                    maxCy=max(cY);
                else
                    maxCy=Size(1)-2;
                end
                %find equivalent green coordinates
                [Xg,Yg]=transformPointsInverse(map.tformlr,cX,cY);
                cXg=round(Xg);
                cYg=round(Yg);
                minCxg=min(cXg);
                minCyg=min(cYg);
                maxCxg=max(cXg);
                maxCyg=max(cYg);
                if max(cXg)>Size(2)-2||max(cYg)>Size(1)-2||min(cXg)<3||min(cYg)<3
                    continue
                else
                    pind=sub2ind(size(acqGreen),cYg,cXg);
                    bgG=acqGreen(minCyg-2:maxCyg+2,minCxg-2:maxCxg+2);
                    bgG(3:3+maxCyg-minCyg,3:3+maxCxg-minCxg)=0;
                    photonsG=[photonsG (mean(acqGreen(pind))-mean(bgG(bgG>0)))*sR(indspotR(idR(j))).Area];
                end
                bgR=acqRed(minCy-2:maxCy+2,minCx-2:maxCx+2);
                bgR(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                photonsR=[photonsR (photonR(idR(j))-mean(bgR(bgR>0)))*sR(indspotR(idR(j))).Area];
            end
    else %no detections in one of the channels
        switch flag
            case 'red'
                if isempty(nidxR)
                    newspots=spotcoordRC;
                else    
                newspots=setdiff(spotcoordRC,spotcoordRC(nidxR,:),'rows');
                end
                indPR=ones(length(photonR),1);
                indPR(nidxR)=0;
                %assigns intensity values
                photonsG=zeros(sum(indPR),1);
                photonsR=zeros(sum(indPR),1);
                indPR=find(indPR);
                %assigns green values corresponding to red spots (only when
                %not meauring AA)               
                for j=1:length(indPR)
                    cY=sR(indspotR(indPR(j))).PixelList(:,2);
                    cX=sR(indspotR(indPR(j))).PixelList(:,1);
                    %make sure the boundaries are within the image
                    if min(cX)>2
                        minCx=min(cX);
                    else
                        minCx=3;
                    end
                    if max(cX)<Size(2)-2
                        maxCx=max(cX);
                    else
                        maxCx=Size(2)-2;
                    end
                    if min(cY)>2
                        minCy=min(cY);
                    else
                        minCy=3;
                    end
                    if max(cY)<Size(1)-2
                        maxCy=max(cY);
                    else
                        maxCy=Size(1)-2;
                    end
                    if (rem(i,2)~=0&&Mode==2)||Mode~=2
                        %find equivalent green coordinates
                        [Xg,Yg]=transformPointsInverse(map.tformlr,cX,cY);
                        cXg=round(Xg);
                        cYg=round(Yg);
                        minCxg=min(cXg);
                        minCyg=min(cYg);
                        maxCxg=max(cXg);
                        maxCyg=max(cYg);
                        if max(cXg)>Size(2)-2||max(cYg)>Size(1)-2||min(cXg)<3||min(cYg)<3
                            continue
                        else
                            pind=sub2ind(size(acqGreen),cYg,cXg);  
                            bgG=acqGreen(minCyg-2:maxCyg+2,minCxg-2:maxCxg+2);
                            bgG(3:3+maxCyg-minCyg,3:3+maxCxg-minCxg)=0;
                            photonsG(j)=(mean(acqGreen(pind))-mean(bgG(bgG>0)))*sR(indspotR(indPR(j))).Area;
                        end
                    end
                        bgR=acqRed(minCy-2:maxCy+2,minCx-2:maxCx+2);
                        bgR(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                        photonsR(j)=(photonR(indPR(j))-mean(bgR(bgR>0)))*sR(indspotR(indPR(j))).Area;
                end
            case 'green'
                if isempty(nidxG)
                    newspots=spotcoordGC;
                else    
                    newspots=setdiff(spotcoordGC,spotcoordGC(nidxG,:),'rows');
                end
                indPG=ones(length(photonG),1);
                indPG(nidxG)=0;
                photonsR=zeros(sum(indPG),1);
                photonsG=zeros(sum(indPG),1);
                indPG=find(indPG);
                for j=1:length(indPG)
                    cY=sG(indspotG(indPG(j))).PixelList(:,2);
                    cX=sG(indspotG(indPG(j))).PixelList(:,1);
                    %make sure the boundaries are within the image
                    if min(cX)>2
                        minCx=min(cX);
                    else
                        minCx=3;
                    end
                    if max(cX)<Size(2)-2
                        maxCx=max(cX);
                    else
                        maxCx=Size(2)-2;
                    end
                    if min(cY)>2
                        minCy=min(cY);
                    else
                        minCy=3;
                    end
                    if max(cY)<Size(1)-2
                        maxCy=max(cY);
                    else
                        maxCy=Size(1)-2;
                    end
                    %get equivalent red coordinates
                    [Xr,Yr]=transformPointsInverse(map.tformrl,cX,cY);
                    cXr=round(Xr);
                    cYr=round(Yr);
                    minCxr=min(cXr);
                    minCyr=min(cYr);
                    maxCxr=max(cXr);
                    maxCyr=max(cYr);
                    if max(cXr)>Size(2)-2||max(cYr)>Size(1)-2||min(cXr)<3||min(cYr)<3
                            continue
                    else
                        bgR=acqRed(minCyr-2:maxCyr+2,minCxr-2:maxCxr+2);
                        bgR(3:3+maxCyr-minCyr,3:3+maxCxr-minCxr)=0;
                        bgG=acqGreen(minCy-2:maxCy+2,minCx-2:maxCx+2);
                        bgG(3:3+maxCy-minCy,3:3+maxCx-minCx)=0;
                        pind=sub2ind(size(acqRed),cYr,cXr);
                        photonsR(j)=(mean(acqRed(pind))-mean(bgR(bgR>0)))*sG(indspotG(indPG(j))).Area;
                        photonsG(j)=(photonG(indPG(j))-mean(bgG(bgG>0)))*sG(indspotG(indPG(j))).Area;
                    end
                end
        end
    end
    newspotnum=length(newspots(:,1));
    if newspotnum>0
        if ~isempty(mRG)
            coLocs=zeros(length(mRG),2);
            coLocs(:,1)=i;
            coLocs(:,2)=maxcoord/2+1:1:maxcoord/2+length(mRG);
            coLocInd=[coLocInd; coLocs];
        end   
        tracks(1).coords(i,maxcoord+1:2:maxcoord+1+2*(newspotnum-1))=newspots(:,1);
        tracks(1).coords(i,maxcoord+2:2:maxcoord+2+2*(newspotnum-1))=newspots(:,2);
        tracks(1).photons(i,maxcoord/2+1:maxcoord/2+length(photonsG))=photonsG;
        tracks(2).photons(i,maxcoord/2+1:maxcoord/2+length(photonsG))=photonsR;
        maxcoord=maxcoord+2+2*(newspotnum-1);
    end    
end    
tracks(1).coLocs=coLocInd;
tracks(1).coLocFRET=coLocFRET;
if Mode==2
    trackLengths=sum(tracks(1).coords(:,1:2:end)~=0);
    indViable=find(trackLengths>3); %tracks of 4 or more localizations needed for Alex analysis
    viableTracks=tracks(1).coords(:,2*indViable-1);
    [~,row]=max(viableTracks~=0,[],1); %finds first non zero element of every column in viableTracks
    indUneven=find(rem(row,2)~=0); % find tracks of 4 or more coordinates which start with green excitation
    for i=1:length(indUneven) %calculate FRET and stoichiometry for tracks that start with green excitation
        tracks(1).eFRET(1:2:end,indViable(indUneven(i)))=tracks(2).photons(1:2:end,indViable(indUneven(i)))./(tracks(2).photons(1:2:end,indViable(indUneven(i)))+tracks(1).photons(1:2:end,indViable(indUneven(i))));
        tracks(1).sto(1:2:end,indViable(indUneven(i)))=(tracks(2).photons(1:2:end,indViable(indUneven(i)))+tracks(1).photons(1:2:end,indViable(indUneven(i))))./(tracks(2).photons(1:2:end,indViable(indUneven(i)))+tracks(1).photons(1:2:end,indViable(indUneven(i)))+tracks(2).photons(2:2:end,indViable(indUneven(i))));
    end
    indEven=setdiff(1:length(indViable),indUneven); %tracks of 4 or more that start with red excitation
    indTrack5=find(trackLengths(indViable(indEven))>4); %if the track starts in red demand at least length 5 for analysis
    for i=1:length(indTrack5)
        Startind=find(viableTracks(:,indEven(indTrack5(i))));%find the first non zero value, use only the red excitations that follows the first green excitation
        if Startind(1)>length(tracks(1).coords(:,1))-5
            continue
        end
        %length of the current track
        tracks(1).eFRET(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i))))=tracks(2).photons(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i))))./(tracks(2).photons(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i))))+tracks(1).photons(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i)))));
        tracks(1).sto(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i))))=(tracks(2).photons(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i))))+tracks(1).photons(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i)))))./...
            (tracks(2).photons(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i))))+tracks(1).photons(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i))))+tracks(2).photons(Startind(1)+1:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-2,indViable(indEven(indTrack5(i))))+tracks(2).photons(Startind(1)+2:2:Startind(1)+trackLengths(indViable(indEven(indTrack5(i))))-1,indViable(indEven(indTrack5(i)))));
    end    
    tracks(1).eFRET(isnan(tracks(1).eFRET))=0;
    tracks(1).sto(isnan(tracks(1).sto)|tracks(1).sto<0)=0;
    %create two columns for stoichiometry and eFRET after eliminating
    %outliers (under 0, over 1 and NAN)
    histFRET=[tracks(1).eFRET(tracks(1).eFRET>0&tracks(1).eFRET<1) tracks(1).sto(tracks(1).eFRET>0&tracks(1).eFRET<1)];
    histFRET(histFRET(:,2)>1.2&histFRET(:,2)<-0.2,:)=[];
    figure;
    %create Bivariate histogram
    h=hist3(histFRET,[30 30]);
    %create grid for visualization
    xb = linspace(0,1,size(h,1));
    yb = linspace(min(histFRET(:,2)),max(histFRET(:,2)),size(h,1));
    %create pseudocolor image of the histogram
    pcolor(xb,flip(yb),h')
    xlabel('E*');
    ylabel('S');
    colormap('jet')
    caxis([0 10])
else
    tracks(1).eFRET=tracks(2).photons./(tracks(1).photons+tracks(2).photons);
end    
save(fullfile(PathName,strcat(fileName(1:end-4),'.FRETtracks.mat')),'tracks','totFrames','PathName','fileName','View','Mode','-v7.3');
end   