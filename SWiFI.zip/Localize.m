function [spotcoord,spotInt,spotsarea,s]=Localize(I,minSize,maxSize,S,Neighbourhood)
%%segments using adaptive Otsu with a user defined neighborhood and localizes using the centroid method and retrieves the intensity weighted
%%centroid, the mean intensity, the size of the spot and the spot pixel
%%values
if nargin<4
    S=0.55;
end
BW=imbinarize(I,adaptthresh(I,S,'NeighborhoodSize',Neighbourhood));
BW2=bwareaopen(BW,minSize)&~bwareaopen(BW,maxSize);
if nargout==1
    s=regionprops(BW2,I,{'WeightedCentroid','PixelList'});
else
    s=regionprops(BW2,I,{'MeanIntensity','WeightedCentroid','Area','PixelList'});
end
if ~isempty(s)
    spotcoord=extractfield(s,'WeightedCentroid');
    if nargout>1
        spotInt=extractfield(s,'MeanIntensity');
        spotsarea=extractfield(s,'Area');
    end
else
    spotcoord=[];spotInt=[];spotsarea=[];
end


