function [Stats]=diffAnalysis(tracks,expTime,Size) %expTime -exposure in seconds
dX=[];
dY=[];
Xjk=[];
Yjk=[];
XYjk=[];
edgeInd=zeros(length(tracks(1).coords(1,:)),1);
for i=1:2:length(tracks(1).coords(1,:))
    if mean(tracks(1).coords(tracks(1).coords(:,i)>0,i))<10||mean(tracks(1).coords(tracks(1).coords(:,i)>0,i))>(Size(2)-10)
        edgeInd(i:i+1)=1;
    end
    if mean(tracks(1).coords(tracks(1).coords(:,i+1)>0,i+1))<10||mean(tracks(1).coords(tracks(1).coords(:,i+1)>0,i+1))>(Size(1)-10)
        edgeInd(i:i+1)=1;
    end
end    
tracks(1).coords(:,logical(edgeInd))=0;
for i=1:2:length(tracks(1).coords(1,:))/2
    dx=diff(tracks(1).coords(tracks(1).coords(:,2*i-1)~=0,2*i-1));
    dy=diff(tracks(1).coords(tracks(1).coords(:,2*i)~=0,2*i));
    dX=[dX;dx];
    dY=[dY;dy];
    Xjk=[Xjk;dx(2:end).*dx(1:end-1)];
    Yjk=[Yjk;dy(2:end).*dy(1:end-1)];
    XYjk=[XYjk;dx.*dy];
end
figure;
subplot(2,2,1); histogram(dX,100);
subplot(2,2,2); histogram(dY,100);
subplot(2,2,3);H=histogram(abs(dX),100);
subplot(2,2,4);G=histogram(abs(dY),100);
binCen=(H.BinEdges(1:end-1)+H.BinEdges(2:end))/2;
for i=1:length(binCen)
    if sum(H.Values(1:i))/sum(H.Values)>0.99
        Stats.ThresholdX=binCen(i);
        break
    end
end    
binCen=(G.BinEdges(1:end-1)+G.BinEdges(2:end))/2;
for i=1:length(binCen)
    if sum(G.Values(1:i))/sum(G.Values)>0.99
        Stats.ThresholdY=binCen(i);
        break
    end
end    
Stats.meandX=mean(abs(dX));
Stats.stdDx=std(dX);
Stats.AbsStddX=std(abs(dX));
Stats.meandY=mean(abs(dY));
Stats.stdDy=std(dY);
Stats.AbsStddY=std(abs(dY));
Stats.Dx=(mean(dX.^2)/(2*expTime)+mean(Xjk)/expTime)*117e-9^2;
Stats.Dy=(mean(dY.^2)/(2*expTime)+mean(Yjk)/expTime)*117e-9^2;
Stats.crossCor=mean(XYjk)/expTime*117e-9^2;
Stats.sigmaX=sqrt(2/6*Stats.Dx*expTime-mean(Xjk)*117e-9^2);
Stats.sigmaY=sqrt(2/6*Stats.Dy*expTime-mean(Yjk)*117e-9^2);

